namespace Demo_Application_for_AITabPanel
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aiTabPanel6 = new AcceleratedIdeas.AITabPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.aiTabPanel5 = new AcceleratedIdeas.AITabPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.aiTabPanel4 = new AcceleratedIdeas.AITabPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.aiTabPanel3 = new AcceleratedIdeas.AITabPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.aiTabPanel2 = new AcceleratedIdeas.AITabPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.aiTabPanel1 = new AcceleratedIdeas.AITabPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.aiTabPanel6.SuspendLayout();
            this.aiTabPanel5.SuspendLayout();
            this.aiTabPanel4.SuspendLayout();
            this.aiTabPanel3.SuspendLayout();
            this.aiTabPanel2.SuspendLayout();
            this.aiTabPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // aiTabPanel6
            // 
            this.aiTabPanel6.BorderColor = System.Drawing.Color.SlateGray;
            this.aiTabPanel6.Controls.Add(this.label16);
            this.aiTabPanel6.Controls.Add(this.button11);
            this.aiTabPanel6.Controls.Add(this.label17);
            this.aiTabPanel6.Controls.Add(this.button12);
            this.aiTabPanel6.Controls.Add(this.label18);
            this.aiTabPanel6.Location = new System.Drawing.Point(403, 179);
            this.aiTabPanel6.MainBendFrom = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(241)))), ((int)(((byte)(222)))));
            this.aiTabPanel6.MainBendTo = System.Drawing.Color.White;
            this.aiTabPanel6.Name = "aiTabPanel6";
            this.aiTabPanel6.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel6.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._CUSTOM;
            this.aiTabPanel6.TabIndex = 6;
            this.aiTabPanel6.TopBendFrom = System.Drawing.Color.White;
            this.aiTabPanel6.TopBendTo = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(225)))), ((int)(((byte)(181)))));
            this.aiTabPanel6.TopPanelHeight = 36;
            this.aiTabPanel6.TopPanelWidth = 86;
            this.aiTabPanel6.DesignDPI = 96.0F;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.DarkGreen;
            this.label16.Location = new System.Drawing.Point(28, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "Save a file";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(101, 79);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(40, 23);
            this.button11.TabIndex = 2;
            this.button11.Text = "Save";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.DarkGreen;
            this.label17.Location = new System.Drawing.Point(28, 55);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Load a file";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(101, 50);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(40, 23);
            this.button12.TabIndex = 1;
            this.button12.Text = "Load";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(28, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 13);
            this.label18.TabIndex = 1;
            this.label18.Text = "Custom Style";
            // 
            // aiTabPanel5
            // 
            this.aiTabPanel5.BorderColor = System.Drawing.Color.Olive;
            this.aiTabPanel5.Controls.Add(this.label13);
            this.aiTabPanel5.Controls.Add(this.button9);
            this.aiTabPanel5.Controls.Add(this.label14);
            this.aiTabPanel5.Controls.Add(this.button10);
            this.aiTabPanel5.Controls.Add(this.label15);
            this.aiTabPanel5.Location = new System.Drawing.Point(208, 179);
            this.aiTabPanel5.MainBendFrom = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(213)))));
            this.aiTabPanel5.MainBendTo = System.Drawing.Color.White;
            this.aiTabPanel5.Name = "aiTabPanel5";
            this.aiTabPanel5.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel5.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._CUSTOM;
            this.aiTabPanel5.TabIndex = 5;
            this.aiTabPanel5.TopBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel5.TopBendTo = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(172)))));
            this.aiTabPanel5.TopPanelHeight = 36;
            this.aiTabPanel5.TopPanelWidth = 86;
            this.aiTabPanel5.DesignDPI = 96.0F;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.ForeColor = System.Drawing.Color.Firebrick;
            this.label13.Location = new System.Drawing.Point(28, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Save a file";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(101, 79);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 23);
            this.button9.TabIndex = 2;
            this.button9.Text = "Save";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.Firebrick;
            this.label14.Location = new System.Drawing.Point(28, 55);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Load a file";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(101, 50);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(40, 23);
            this.button10.TabIndex = 1;
            this.button10.Text = "Load";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(28, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "Custom Style";
            // 
            // aiTabPanel4
            // 
            this.aiTabPanel4.BorderColor = System.Drawing.Color.SteelBlue;
            this.aiTabPanel4.Controls.Add(this.label10);
            this.aiTabPanel4.Controls.Add(this.button7);
            this.aiTabPanel4.Controls.Add(this.label11);
            this.aiTabPanel4.Controls.Add(this.button8);
            this.aiTabPanel4.Controls.Add(this.label12);
            this.aiTabPanel4.Location = new System.Drawing.Point(12, 179);
            this.aiTabPanel4.MainBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel4.MainBendTo = System.Drawing.Color.LightSteelBlue;
            this.aiTabPanel4.Name = "aiTabPanel4";
            this.aiTabPanel4.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel4.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._BUSINESS;
            this.aiTabPanel4.TabIndex = 4;
            this.aiTabPanel4.TopBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel4.TopBendTo = System.Drawing.Color.DodgerBlue;
            this.aiTabPanel4.TopPanelHeight = 36;
            this.aiTabPanel4.TopPanelWidth = 95;
            this.aiTabPanel4.DesignDPI = 96.0F;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(28, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 3;
            this.label10.Text = "Save a file";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(101, 79);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(40, 23);
            this.button7.TabIndex = 2;
            this.button7.Text = "Save";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(28, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Load a file";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(101, 50);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(40, 23);
            this.button8.TabIndex = 1;
            this.button8.Text = "Load";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(28, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Business Style";
            // 
            // aiTabPanel3
            // 
            this.aiTabPanel3.BorderColor = System.Drawing.Color.RoyalBlue;
            this.aiTabPanel3.Controls.Add(this.label7);
            this.aiTabPanel3.Controls.Add(this.button5);
            this.aiTabPanel3.Controls.Add(this.label8);
            this.aiTabPanel3.Controls.Add(this.button6);
            this.aiTabPanel3.Controls.Add(this.label9);
            this.aiTabPanel3.Location = new System.Drawing.Point(403, 23);
            this.aiTabPanel3.MainBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel3.MainBendTo = System.Drawing.Color.LightSteelBlue;
            this.aiTabPanel3.Name = "aiTabPanel3";
            this.aiTabPanel3.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel3.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._AI1;
            this.aiTabPanel3.TabIndex = 5;
            this.aiTabPanel3.TopBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel3.TopBendTo = System.Drawing.Color.DodgerBlue;
            this.aiTabPanel3.TopPanelHeight = 36;
            this.aiTabPanel3.TopPanelWidth = 58;
            this.aiTabPanel3.DesignDPI = 96.0F;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(28, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Save a file";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(101, 79);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 23);
            this.button5.TabIndex = 2;
            this.button5.Text = "Save";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(28, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Load a file";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(101, 50);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(40, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "Load";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(28, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "AI Style";
            // 
            // aiTabPanel2
            // 
            this.aiTabPanel2.BorderColor = System.Drawing.Color.DarkGray;
            this.aiTabPanel2.Controls.Add(this.label4);
            this.aiTabPanel2.Controls.Add(this.button3);
            this.aiTabPanel2.Controls.Add(this.label5);
            this.aiTabPanel2.Controls.Add(this.button4);
            this.aiTabPanel2.Controls.Add(this.label6);
            this.aiTabPanel2.Location = new System.Drawing.Point(208, 23);
            this.aiTabPanel2.MainBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel2.MainBendTo = System.Drawing.Color.LightSteelBlue;
            this.aiTabPanel2.Name = "aiTabPanel2";
            this.aiTabPanel2.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel2.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._XP;
            this.aiTabPanel2.TabIndex = 4;
            this.aiTabPanel2.TopBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel2.TopBendTo = System.Drawing.Color.DodgerBlue;
            this.aiTabPanel2.TopPanelHeight = 36;
            this.aiTabPanel2.TopPanelWidth = 60;
            this.aiTabPanel2.DesignDPI = 96.0F;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(28, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Save a file";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(101, 79);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(28, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Load a file";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(101, 50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 23);
            this.button4.TabIndex = 1;
            this.button4.Text = "Load";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(28, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "XP Style";
            // 
            // aiTabPanel1
            // 
            this.aiTabPanel1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(150)))), ((int)(((byte)(230)))));
            this.aiTabPanel1.Controls.Add(this.label3);
            this.aiTabPanel1.Controls.Add(this.button2);
            this.aiTabPanel1.Controls.Add(this.label2);
            this.aiTabPanel1.Controls.Add(this.button1);
            this.aiTabPanel1.Controls.Add(this.label1);
            this.aiTabPanel1.Location = new System.Drawing.Point(12, 23);
            this.aiTabPanel1.MainBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel1.MainBendTo = System.Drawing.Color.LightSteelBlue;
            this.aiTabPanel1.Name = "aiTabPanel1";
            this.aiTabPanel1.Size = new System.Drawing.Size(177, 140);
            this.aiTabPanel1.StyleType = AcceleratedIdeas.AITabPanel.AIStyleTypes._VISTA;
            this.aiTabPanel1.TabIndex = 0;
            this.aiTabPanel1.TopBendFrom = System.Drawing.Color.Empty;
            this.aiTabPanel1.TopBendTo = System.Drawing.Color.DodgerBlue;
            this.aiTabPanel1.TopPanelHeight = 36;
            this.aiTabPanel1.TopPanelWidth = 78;
            this.aiTabPanel1.DesignDPI = 96.0F;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(28, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Save a file";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(101, 79);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(40, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.MediumBlue;
            this.label2.Location = new System.Drawing.Point(28, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Load a file";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(101, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Load";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(28, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vista Style";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(601, 358);
            this.Controls.Add(this.aiTabPanel6);
            this.Controls.Add(this.aiTabPanel5);
            this.Controls.Add(this.aiTabPanel4);
            this.Controls.Add(this.aiTabPanel3);
            this.Controls.Add(this.aiTabPanel2);
            this.Controls.Add(this.aiTabPanel1);
            this.Name = "MainForm";
            this.Text = "Demo Application for AITabPanel";
            this.aiTabPanel6.ResumeLayout(false);
            this.aiTabPanel6.PerformLayout();
            this.aiTabPanel5.ResumeLayout(false);
            this.aiTabPanel5.PerformLayout();
            this.aiTabPanel4.ResumeLayout(false);
            this.aiTabPanel4.PerformLayout();
            this.aiTabPanel3.ResumeLayout(false);
            this.aiTabPanel3.PerformLayout();
            this.aiTabPanel2.ResumeLayout(false);
            this.aiTabPanel2.PerformLayout();
            this.aiTabPanel1.ResumeLayout(false);
            this.aiTabPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private AcceleratedIdeas.AITabPanel aiTabPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private AcceleratedIdeas.AITabPanel aiTabPanel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label6;
        private AcceleratedIdeas.AITabPanel aiTabPanel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label9;
        private AcceleratedIdeas.AITabPanel aiTabPanel4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label12;
        private AcceleratedIdeas.AITabPanel aiTabPanel5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label15;
        private AcceleratedIdeas.AITabPanel aiTabPanel6;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label18;
    }
}

